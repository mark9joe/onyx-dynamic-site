export default function Home() {
  return (
    <main style={{ padding: '2rem' }}>
      <h1>Welcome to RespireWork</h1>
      <p>This is your homepage. Dynamic SEO pages are now enabled using ISR.</p>
    </main>
  );
}
